const Discord = require('discord.js');
const {
  Client,
  MessageActionRow,
  MessageButton,
  MessageEmbed,
  Intents
} = require("discord.js");

const ms = require("ms");

module.exports = {
  name: "mute",
  aliases: ["ميوت"],
  description: "Mute a user with a specified reason and duration",
  usage: "[id or mention]",
  botPermission: ["MUTE_MEMBERS"],
  authorPermissions: ["MUTE_MEMBERS"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client2, message, args) => {
    if (!message.guild) return;

    // Fetch the member by mention or ID
    const member = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => {});

    // Check if the member and message.member are valid
    if (!member) return message.reply({ content: `❗ **I can't find this member**`, ephemeral: true });
    if (!message.member) return message.reply({ content: `❗ **Unable to fetch your member information**`, ephemeral: true });
    if (member.id === message.member.id) return message.reply({ content: `❗ **You can't mute yourself**`, ephemeral: true });
    if (message.member.roles.highest.position < member.roles.highest.position) return message.reply({ content: `❗ **You can't mute ${member.user.username} because they have a higher role than you**`, ephemeral: true });

    // Creating a panel with reasons and corresponding durations
    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('mute_spam')
          .setLabel('Spamming (5m)')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('mute_offensive')
          .setLabel('Offensive Language (15m)')
          .setStyle('DANGER'),
        new MessageButton()
          .setCustomId('mute_disruption')
          .setLabel('Disruption (1h)')
          .setStyle('SECONDARY')
      );

    const embed = new MessageEmbed()
      .setTitle("Select Mute Reason")
      .setDescription("Please select a reason to mute the user.")
      .setColor("RED");

    await message.reply({ embeds: [embed], components: [row], ephemeral: true });

    const filter = i => i.user.id === message.member.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 });

    collector.on('collect', async i => {
      if (!i.isButton()) return;

      let time;
      let reason;

      switch (i.customId) {
        case 'mute_spam':
          time = '5m';
          reason = 'Spamming';
          break;
        case 'mute_offensive':
          time = '15m';
          reason = 'Offensive Language';
          break;
        case 'mute_disruption':
          time = '1h';
          reason = 'Disruption';
          break;
        default:
          return;
      }

      // Check if the member is connected to a voice channel
      if (member.voice.channel) {
        try {
          await member.voice.setMute(true, `${reason} - Muted by ${message.member.user.tag}`);
          await i.update({ content: `:white_check_mark: **${member.user.username} has been muted for ${reason} (${time})!**`, components: [] });

          // Unmute after the specified duration
          setTimeout(async () => {
            if (member.voice.serverMute) {
              await member.voice.setMute(false, `Mute duration ended.`);
              await message.channel.send({ content: `:white_check_mark: **${member.user.username} is now unmuted!**` });
            }
          }, ms(time));
        } catch (err) {
          console.error(err);
          await i.update({ content: `❗ **An error occurred while muting ${member.user.username}.**`, components: [] });
        }
      } else {
        await i.update({ content: `❗ **${member.user.username} is not connected to a voice channel. Cannot mute.**`, components: [] });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        message.channel.send({ content: `❗ **Mute action timed out. No selection made.**` });
      }
    });
  }
};
